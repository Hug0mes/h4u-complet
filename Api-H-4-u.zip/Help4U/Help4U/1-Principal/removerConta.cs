﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Help4U
{
    public partial class removerConta : Form
    {
        public removerConta()
        {
            InitializeComponent();
        }

        private void removerConta_Load(object sender, EventArgs e)
        {

        }
    }
}
