﻿namespace Help4U
{
    partial class top1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.guna2PictureBox7 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox1 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox2 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox3 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox4 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox5 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.guna2PictureBox6 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox8 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox9 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox10 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox11 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox12 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.guna2PictureBox13 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox14 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox15 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.label5 = new System.Windows.Forms.Label();
            this.guna2PictureBox16 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox17 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox18 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.guna2PictureBox19 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox20 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox21 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.guna2PictureBox25 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox26 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox27 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.label9 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox27)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(21, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 18);
            this.label1.TabIndex = 2;
            this.label1.Text = "Ver mais ->";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // guna2PictureBox7
            // 
            this.guna2PictureBox7.BorderRadius = 5;
            this.guna2PictureBox7.ImageRotate = 0F;
            this.guna2PictureBox7.Location = new System.Drawing.Point(15, 65);
            this.guna2PictureBox7.Name = "guna2PictureBox7";
            this.guna2PictureBox7.Size = new System.Drawing.Size(253, 179);
            this.guna2PictureBox7.TabIndex = 73;
            this.guna2PictureBox7.TabStop = false;
            this.guna2PictureBox7.Click += new System.EventHandler(this.guna2PictureBox7_Click);
            // 
            // guna2PictureBox1
            // 
            this.guna2PictureBox1.BorderRadius = 5;
            this.guna2PictureBox1.ImageRotate = 0F;
            this.guna2PictureBox1.Location = new System.Drawing.Point(288, 65);
            this.guna2PictureBox1.Name = "guna2PictureBox1";
            this.guna2PictureBox1.Size = new System.Drawing.Size(253, 179);
            this.guna2PictureBox1.TabIndex = 74;
            this.guna2PictureBox1.TabStop = false;
            this.guna2PictureBox1.Click += new System.EventHandler(this.guna2PictureBox1_Click);
            // 
            // guna2PictureBox2
            // 
            this.guna2PictureBox2.BorderRadius = 5;
            this.guna2PictureBox2.ImageRotate = 0F;
            this.guna2PictureBox2.Location = new System.Drawing.Point(563, 65);
            this.guna2PictureBox2.Name = "guna2PictureBox2";
            this.guna2PictureBox2.Size = new System.Drawing.Size(253, 179);
            this.guna2PictureBox2.TabIndex = 75;
            this.guna2PictureBox2.TabStop = false;
            this.guna2PictureBox2.Click += new System.EventHandler(this.guna2PictureBox2_Click);
            // 
            // guna2PictureBox3
            // 
            this.guna2PictureBox3.BorderRadius = 5;
            this.guna2PictureBox3.ImageRotate = 0F;
            this.guna2PictureBox3.Location = new System.Drawing.Point(557, -562);
            this.guna2PictureBox3.Name = "guna2PictureBox3";
            this.guna2PictureBox3.Size = new System.Drawing.Size(253, 179);
            this.guna2PictureBox3.TabIndex = 80;
            this.guna2PictureBox3.TabStop = false;
            // 
            // guna2PictureBox4
            // 
            this.guna2PictureBox4.BorderRadius = 5;
            this.guna2PictureBox4.ImageRotate = 0F;
            this.guna2PictureBox4.Location = new System.Drawing.Point(289, -562);
            this.guna2PictureBox4.Name = "guna2PictureBox4";
            this.guna2PictureBox4.Size = new System.Drawing.Size(253, 179);
            this.guna2PictureBox4.TabIndex = 79;
            this.guna2PictureBox4.TabStop = false;
            // 
            // guna2PictureBox5
            // 
            this.guna2PictureBox5.BorderRadius = 5;
            this.guna2PictureBox5.ImageRotate = 0F;
            this.guna2PictureBox5.Location = new System.Drawing.Point(18, -562);
            this.guna2PictureBox5.Name = "guna2PictureBox5";
            this.guna2PictureBox5.Size = new System.Drawing.Size(253, 179);
            this.guna2PictureBox5.TabIndex = 78;
            this.guna2PictureBox5.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(22, -589);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 18);
            this.label2.TabIndex = 77;
            this.label2.Text = "Ver mais ->";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(21, 275);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(84, 18);
            this.label3.TabIndex = 81;
            this.label3.Text = "Ver mais ->";
            // 
            // guna2PictureBox6
            // 
            this.guna2PictureBox6.BorderRadius = 5;
            this.guna2PictureBox6.ImageRotate = 0F;
            this.guna2PictureBox6.Location = new System.Drawing.Point(12, 296);
            this.guna2PictureBox6.Name = "guna2PictureBox6";
            this.guna2PictureBox6.Size = new System.Drawing.Size(253, 179);
            this.guna2PictureBox6.TabIndex = 82;
            this.guna2PictureBox6.TabStop = false;
            // 
            // guna2PictureBox8
            // 
            this.guna2PictureBox8.BorderRadius = 5;
            this.guna2PictureBox8.ImageRotate = 0F;
            this.guna2PictureBox8.Location = new System.Drawing.Point(563, 296);
            this.guna2PictureBox8.Name = "guna2PictureBox8";
            this.guna2PictureBox8.Size = new System.Drawing.Size(253, 179);
            this.guna2PictureBox8.TabIndex = 84;
            this.guna2PictureBox8.TabStop = false;
            // 
            // guna2PictureBox9
            // 
            this.guna2PictureBox9.BorderRadius = 5;
            this.guna2PictureBox9.ImageRotate = 0F;
            this.guna2PictureBox9.Location = new System.Drawing.Point(288, 296);
            this.guna2PictureBox9.Name = "guna2PictureBox9";
            this.guna2PictureBox9.Size = new System.Drawing.Size(253, 179);
            this.guna2PictureBox9.TabIndex = 83;
            this.guna2PictureBox9.TabStop = false;
            // 
            // guna2PictureBox10
            // 
            this.guna2PictureBox10.BorderRadius = 5;
            this.guna2PictureBox10.ImageRotate = 0F;
            this.guna2PictureBox10.Location = new System.Drawing.Point(563, 750);
            this.guna2PictureBox10.Name = "guna2PictureBox10";
            this.guna2PictureBox10.Size = new System.Drawing.Size(253, 179);
            this.guna2PictureBox10.TabIndex = 92;
            this.guna2PictureBox10.TabStop = false;
            // 
            // guna2PictureBox11
            // 
            this.guna2PictureBox11.BorderRadius = 5;
            this.guna2PictureBox11.ImageRotate = 0F;
            this.guna2PictureBox11.Location = new System.Drawing.Point(288, 750);
            this.guna2PictureBox11.Name = "guna2PictureBox11";
            this.guna2PictureBox11.Size = new System.Drawing.Size(253, 179);
            this.guna2PictureBox11.TabIndex = 91;
            this.guna2PictureBox11.TabStop = false;
            // 
            // guna2PictureBox12
            // 
            this.guna2PictureBox12.BorderRadius = 5;
            this.guna2PictureBox12.ImageRotate = 0F;
            this.guna2PictureBox12.Location = new System.Drawing.Point(12, 750);
            this.guna2PictureBox12.Name = "guna2PictureBox12";
            this.guna2PictureBox12.Size = new System.Drawing.Size(253, 179);
            this.guna2PictureBox12.TabIndex = 90;
            this.guna2PictureBox12.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(21, 729);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(84, 18);
            this.label4.TabIndex = 89;
            this.label4.Text = "Ver mais ->";
            // 
            // guna2PictureBox13
            // 
            this.guna2PictureBox13.BorderRadius = 5;
            this.guna2PictureBox13.ImageRotate = 0F;
            this.guna2PictureBox13.Location = new System.Drawing.Point(563, 519);
            this.guna2PictureBox13.Name = "guna2PictureBox13";
            this.guna2PictureBox13.Size = new System.Drawing.Size(253, 179);
            this.guna2PictureBox13.TabIndex = 88;
            this.guna2PictureBox13.TabStop = false;
            // 
            // guna2PictureBox14
            // 
            this.guna2PictureBox14.BorderRadius = 5;
            this.guna2PictureBox14.ImageRotate = 0F;
            this.guna2PictureBox14.Location = new System.Drawing.Point(288, 519);
            this.guna2PictureBox14.Name = "guna2PictureBox14";
            this.guna2PictureBox14.Size = new System.Drawing.Size(253, 179);
            this.guna2PictureBox14.TabIndex = 87;
            this.guna2PictureBox14.TabStop = false;
            // 
            // guna2PictureBox15
            // 
            this.guna2PictureBox15.BorderRadius = 5;
            this.guna2PictureBox15.ImageRotate = 0F;
            this.guna2PictureBox15.Location = new System.Drawing.Point(15, 519);
            this.guna2PictureBox15.Name = "guna2PictureBox15";
            this.guna2PictureBox15.Size = new System.Drawing.Size(253, 179);
            this.guna2PictureBox15.TabIndex = 86;
            this.guna2PictureBox15.TabStop = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(21, 498);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(84, 18);
            this.label5.TabIndex = 85;
            this.label5.Text = "Ver mais ->";
            // 
            // guna2PictureBox16
            // 
            this.guna2PictureBox16.BorderRadius = 5;
            this.guna2PictureBox16.ImageRotate = 0F;
            this.guna2PictureBox16.Location = new System.Drawing.Point(560, 1213);
            this.guna2PictureBox16.Name = "guna2PictureBox16";
            this.guna2PictureBox16.Size = new System.Drawing.Size(253, 179);
            this.guna2PictureBox16.TabIndex = 100;
            this.guna2PictureBox16.TabStop = false;
            // 
            // guna2PictureBox17
            // 
            this.guna2PictureBox17.BorderRadius = 5;
            this.guna2PictureBox17.ImageRotate = 0F;
            this.guna2PictureBox17.Location = new System.Drawing.Point(285, 1213);
            this.guna2PictureBox17.Name = "guna2PictureBox17";
            this.guna2PictureBox17.Size = new System.Drawing.Size(253, 179);
            this.guna2PictureBox17.TabIndex = 99;
            this.guna2PictureBox17.TabStop = false;
            // 
            // guna2PictureBox18
            // 
            this.guna2PictureBox18.BorderRadius = 5;
            this.guna2PictureBox18.ImageRotate = 0F;
            this.guna2PictureBox18.Location = new System.Drawing.Point(9, 1213);
            this.guna2PictureBox18.Name = "guna2PictureBox18";
            this.guna2PictureBox18.Size = new System.Drawing.Size(253, 179);
            this.guna2PictureBox18.TabIndex = 98;
            this.guna2PictureBox18.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(18, 1192);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(84, 18);
            this.label6.TabIndex = 97;
            this.label6.Text = "Ver mais ->";
            // 
            // guna2PictureBox19
            // 
            this.guna2PictureBox19.BorderRadius = 5;
            this.guna2PictureBox19.ImageRotate = 0F;
            this.guna2PictureBox19.Location = new System.Drawing.Point(560, 982);
            this.guna2PictureBox19.Name = "guna2PictureBox19";
            this.guna2PictureBox19.Size = new System.Drawing.Size(253, 179);
            this.guna2PictureBox19.TabIndex = 96;
            this.guna2PictureBox19.TabStop = false;
            // 
            // guna2PictureBox20
            // 
            this.guna2PictureBox20.BorderRadius = 5;
            this.guna2PictureBox20.ImageRotate = 0F;
            this.guna2PictureBox20.Location = new System.Drawing.Point(285, 982);
            this.guna2PictureBox20.Name = "guna2PictureBox20";
            this.guna2PictureBox20.Size = new System.Drawing.Size(253, 179);
            this.guna2PictureBox20.TabIndex = 95;
            this.guna2PictureBox20.TabStop = false;
            // 
            // guna2PictureBox21
            // 
            this.guna2PictureBox21.BorderRadius = 5;
            this.guna2PictureBox21.ImageRotate = 0F;
            this.guna2PictureBox21.Location = new System.Drawing.Point(12, 982);
            this.guna2PictureBox21.Name = "guna2PictureBox21";
            this.guna2PictureBox21.Size = new System.Drawing.Size(253, 179);
            this.guna2PictureBox21.TabIndex = 94;
            this.guna2PictureBox21.TabStop = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(18, 961);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(84, 18);
            this.label7.TabIndex = 93;
            this.label7.Text = "Ver mais ->";
            // 
            // guna2PictureBox25
            // 
            this.guna2PictureBox25.BorderRadius = 5;
            this.guna2PictureBox25.ImageRotate = 0F;
            this.guna2PictureBox25.Location = new System.Drawing.Point(560, 1435);
            this.guna2PictureBox25.Name = "guna2PictureBox25";
            this.guna2PictureBox25.Size = new System.Drawing.Size(253, 179);
            this.guna2PictureBox25.TabIndex = 104;
            this.guna2PictureBox25.TabStop = false;
            // 
            // guna2PictureBox26
            // 
            this.guna2PictureBox26.BorderRadius = 5;
            this.guna2PictureBox26.ImageRotate = 0F;
            this.guna2PictureBox26.Location = new System.Drawing.Point(285, 1435);
            this.guna2PictureBox26.Name = "guna2PictureBox26";
            this.guna2PictureBox26.Size = new System.Drawing.Size(253, 179);
            this.guna2PictureBox26.TabIndex = 103;
            this.guna2PictureBox26.TabStop = false;
            // 
            // guna2PictureBox27
            // 
            this.guna2PictureBox27.BorderRadius = 5;
            this.guna2PictureBox27.ImageRotate = 0F;
            this.guna2PictureBox27.Location = new System.Drawing.Point(12, 1435);
            this.guna2PictureBox27.Name = "guna2PictureBox27";
            this.guna2PictureBox27.Size = new System.Drawing.Size(253, 179);
            this.guna2PictureBox27.TabIndex = 102;
            this.guna2PictureBox27.TabStop = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(18, 1414);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(84, 18);
            this.label9.TabIndex = 101;
            this.label9.Text = "Ver mais ->";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(269, 1647);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(10, 43);
            this.button2.TabIndex = 1;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Visible = false;
            // 
            // top1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(849, 772);
            this.Controls.Add(this.guna2PictureBox25);
            this.Controls.Add(this.guna2PictureBox26);
            this.Controls.Add(this.guna2PictureBox27);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.guna2PictureBox16);
            this.Controls.Add(this.guna2PictureBox17);
            this.Controls.Add(this.guna2PictureBox18);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.guna2PictureBox19);
            this.Controls.Add(this.guna2PictureBox20);
            this.Controls.Add(this.guna2PictureBox21);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.guna2PictureBox10);
            this.Controls.Add(this.guna2PictureBox11);
            this.Controls.Add(this.guna2PictureBox12);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.guna2PictureBox13);
            this.Controls.Add(this.guna2PictureBox14);
            this.Controls.Add(this.guna2PictureBox15);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.guna2PictureBox8);
            this.Controls.Add(this.guna2PictureBox9);
            this.Controls.Add(this.guna2PictureBox6);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.guna2PictureBox3);
            this.Controls.Add(this.guna2PictureBox4);
            this.Controls.Add(this.guna2PictureBox5);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.guna2PictureBox2);
            this.Controls.Add(this.guna2PictureBox1);
            this.Controls.Add(this.guna2PictureBox7);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "top1";
            this.Text = " ";
            this.Load += new System.EventHandler(this.top1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox27)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox7;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox1;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox2;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox3;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox4;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox6;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox8;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox9;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox10;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox11;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox12;
        private System.Windows.Forms.Label label4;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox13;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox14;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox15;
        private System.Windows.Forms.Label label5;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox16;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox17;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox18;
        private System.Windows.Forms.Label label6;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox19;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox20;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox21;
        private System.Windows.Forms.Label label7;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox25;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox26;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox27;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button button2;
    }
}