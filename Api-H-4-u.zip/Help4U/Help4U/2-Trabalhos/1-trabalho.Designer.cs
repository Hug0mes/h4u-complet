﻿namespace Help4U
{
    partial class trabalho
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(trabalho));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.construçãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.designToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.escritaETraduçãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.estiloDeVidaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.marketingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.negóciosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tecnologiaEProgramaçãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.trabalhosManuaisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.trabalhosManuaisToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.guna2TextBox1 = new Guna.UI2.WinForms.Guna2TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.listView1 = new System.Windows.Forms.ListView();
            this.guna2Button18 = new Guna.UI2.WinForms.Guna2Button();
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.AutoSize = false;
            this.menuStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(100)))), ((int)(((byte)(110)))));
            this.menuStrip1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.menuStrip1.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.construçãoToolStripMenuItem,
            this.designToolStripMenuItem,
            this.escritaETraduçãoToolStripMenuItem,
            this.estiloDeVidaToolStripMenuItem,
            this.marketingToolStripMenuItem,
            this.negóciosToolStripMenuItem,
            this.tecnologiaEProgramaçãoToolStripMenuItem,
            this.trabalhosManuaisToolStripMenuItem,
            this.trabalhosManuaisToolStripMenuItem1});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(4, 2, 0, 2);
            this.menuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.menuStrip1.Size = new System.Drawing.Size(795, 25);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // construçãoToolStripMenuItem
            // 
            this.construçãoToolStripMenuItem.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.construçãoToolStripMenuItem.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.construçãoToolStripMenuItem.Name = "construçãoToolStripMenuItem";
            this.construçãoToolStripMenuItem.Size = new System.Drawing.Size(91, 21);
            this.construçãoToolStripMenuItem.Text = "Construção";
            // 
            // designToolStripMenuItem
            // 
            this.designToolStripMenuItem.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.designToolStripMenuItem.Name = "designToolStripMenuItem";
            this.designToolStripMenuItem.Size = new System.Drawing.Size(62, 21);
            this.designToolStripMenuItem.Text = "Design ";
            // 
            // escritaETraduçãoToolStripMenuItem
            // 
            this.escritaETraduçãoToolStripMenuItem.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.escritaETraduçãoToolStripMenuItem.Name = "escritaETraduçãoToolStripMenuItem";
            this.escritaETraduçãoToolStripMenuItem.Size = new System.Drawing.Size(122, 21);
            this.escritaETraduçãoToolStripMenuItem.Text = "Escrita e tradução";
            // 
            // estiloDeVidaToolStripMenuItem
            // 
            this.estiloDeVidaToolStripMenuItem.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.estiloDeVidaToolStripMenuItem.Name = "estiloDeVidaToolStripMenuItem";
            this.estiloDeVidaToolStripMenuItem.Size = new System.Drawing.Size(96, 21);
            this.estiloDeVidaToolStripMenuItem.Text = "Estilo de Vida";
            // 
            // marketingToolStripMenuItem
            // 
            this.marketingToolStripMenuItem.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.marketingToolStripMenuItem.Name = "marketingToolStripMenuItem";
            this.marketingToolStripMenuItem.Size = new System.Drawing.Size(75, 21);
            this.marketingToolStripMenuItem.Text = "Marketing";
            // 
            // negóciosToolStripMenuItem
            // 
            this.negóciosToolStripMenuItem.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.negóciosToolStripMenuItem.Name = "negóciosToolStripMenuItem";
            this.negóciosToolStripMenuItem.Size = new System.Drawing.Size(76, 21);
            this.negóciosToolStripMenuItem.Text = "Multimídia";
            // 
            // tecnologiaEProgramaçãoToolStripMenuItem
            // 
            this.tecnologiaEProgramaçãoToolStripMenuItem.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.tecnologiaEProgramaçãoToolStripMenuItem.Name = "tecnologiaEProgramaçãoToolStripMenuItem";
            this.tecnologiaEProgramaçãoToolStripMenuItem.Size = new System.Drawing.Size(70, 21);
            this.tecnologiaEProgramaçãoToolStripMenuItem.Text = "Negócios";
            // 
            // trabalhosManuaisToolStripMenuItem
            // 
            this.trabalhosManuaisToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.trabalhosManuaisToolStripMenuItem.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.trabalhosManuaisToolStripMenuItem.Name = "trabalhosManuaisToolStripMenuItem";
            this.trabalhosManuaisToolStripMenuItem.Size = new System.Drawing.Size(79, 21);
            this.trabalhosManuaisToolStripMenuItem.Text = "Tecnologia";
            // 
            // trabalhosManuaisToolStripMenuItem1
            // 
            this.trabalhosManuaisToolStripMenuItem1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.trabalhosManuaisToolStripMenuItem1.Name = "trabalhosManuaisToolStripMenuItem1";
            this.trabalhosManuaisToolStripMenuItem1.Size = new System.Drawing.Size(124, 21);
            this.trabalhosManuaisToolStripMenuItem1.Text = "Trabalhos Manuais";
            // 
            // guna2TextBox1
            // 
            this.guna2TextBox1.Animated = true;
            this.guna2TextBox1.AutoRoundedCorners = true;
            this.guna2TextBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(100)))), ((int)(((byte)(110)))));
            this.guna2TextBox1.BorderColor = System.Drawing.Color.Empty;
            this.guna2TextBox1.BorderRadius = 11;
            this.guna2TextBox1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox1.DefaultText = "";
            this.guna2TextBox1.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox1.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox1.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2TextBox1.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox1.Location = new System.Drawing.Point(166, 34);
            this.guna2TextBox1.Margin = new System.Windows.Forms.Padding(2);
            this.guna2TextBox1.Name = "guna2TextBox1";
            this.guna2TextBox1.PasswordChar = '\0';
            this.guna2TextBox1.PlaceholderText = "Procure um trabalho ";
            this.guna2TextBox1.SelectedText = "";
            this.guna2TextBox1.Size = new System.Drawing.Size(442, 25);
            this.guna2TextBox1.TabIndex = 19;
            this.guna2TextBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.guna2TextBox1_KeyPress);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(100)))), ((int)(((byte)(110)))));
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Location = new System.Drawing.Point(0, 25);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(795, 48);
            this.label1.TabIndex = 18;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.listView1);
            this.panel1.Location = new System.Drawing.Point(2, 74);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(794, 551);
            this.panel1.TabIndex = 21;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // listView1
            // 
            this.listView1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.listView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(40, 16);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(679, 515);
            this.listView1.TabIndex = 0;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
            this.listView1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.listView1_MouseClick);
            // 
            // guna2Button18
            // 
            this.guna2Button18.Animated = true;
            this.guna2Button18.AutoRoundedCorners = true;
            this.guna2Button18.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button18.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.guna2Button18.BorderRadius = 11;
            this.guna2Button18.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button18.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button18.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button18.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button18.FillColor = System.Drawing.Color.White;
            this.guna2Button18.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button18.ForeColor = System.Drawing.Color.Transparent;
            this.guna2Button18.HoverState.BorderColor = System.Drawing.Color.White;
            this.guna2Button18.HoverState.FillColor = System.Drawing.Color.White;
            this.guna2Button18.Image = ((System.Drawing.Image)(resources.GetObject("guna2Button18.Image")));
            this.guna2Button18.Location = new System.Drawing.Point(613, 34);
            this.guna2Button18.Margin = new System.Windows.Forms.Padding(2);
            this.guna2Button18.Name = "guna2Button18";
            this.guna2Button18.Size = new System.Drawing.Size(26, 25);
            this.guna2Button18.TabIndex = 20;
            this.guna2Button18.UseTransparentBackground = true;
            // 
            // trabalho
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(795, 630);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.guna2Button18);
            this.Controls.Add(this.guna2TextBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "trabalho";
            this.Text = "trabalho";
            this.Load += new System.EventHandler(this.trabalho_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem construçãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem designToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem escritaETraduçãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem estiloDeVidaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem marketingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem negóciosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tecnologiaEProgramaçãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem trabalhosManuaisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem trabalhosManuaisToolStripMenuItem1;
        private Guna.UI2.WinForms.Guna2Button guna2Button18;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ListView listView1;
    }
}