﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Help4U
{
    public partial class perfil : Form
    {
        public perfil()
        {
            InitializeComponent();
        }

        int i=0;

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            guna2Button1.Visible = false;
       
            guna2TextBox1.Enabled = true;
        }

        private void guna2Button3_Click(object sender, EventArgs e)
        {
            guna2Button1.Visible = true;
         
            guna2TextBox1.Enabled = false;
        }

        private void guna2Button4_Click(object sender, EventArgs e)
        {
            definicoes_perfilPessoal f1 = new definicoes_perfilPessoal();
            f1.Show();
            this.Visible = false;
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            guna2Button1.Visible = true;
         

            guna2TextBox1.Enabled = false;
        }

        private void guna2CircleButton1_Click(object sender, EventArgs e)
        {
            Principal principal = new Principal();
            principal.Show();
            this.Close();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            Principal principal = new Principal();
            principal.Show();
            this.Close();
        }

        private void guna2CirclePictureBox1_Click(object sender, EventArgs e)
        {

            OpenFileDialog open = new OpenFileDialog();
            open.Filter = "Image Files(*.jpg; *.jpeg; *.gif; *.bmp)|*.jpg; *.jpeg; *.gif; *.bmp";
            if (open.ShowDialog() == DialogResult.OK)
            {
               guna2CirclePictureBox1.Image = new Bitmap(open.FileName);

                i = 1;
                label4.Visible = true;
            }
        }

        private void guna2TextBox1_TextChanged(object sender, EventArgs e)
        {
            i = 1;
            label4.Visible = true;
        }

        private void pictureBox11_Click(object sender, EventArgs e)
        {
            pictureBox11.BorderStyle = BorderStyle.Fixed3D;
            pictureBox12.BorderStyle = BorderStyle.None;
            pictureBox13.BorderStyle = BorderStyle.None;
            pictureBox14.BorderStyle = BorderStyle.None;
            pictureBox15.BorderStyle = BorderStyle.None;
            pictureBox16.BorderStyle = BorderStyle.None;
            pictureBox17.BorderStyle = BorderStyle.None;
            i = 1;
            label4.Visible = true;
        }

        private void pictureBox12_Click(object sender, EventArgs e)
        {
            pictureBox11.BorderStyle = BorderStyle.None;
            pictureBox12.BorderStyle = BorderStyle.Fixed3D;
            pictureBox13.BorderStyle = BorderStyle.None;
            pictureBox14.BorderStyle = BorderStyle.None;
            pictureBox15.BorderStyle = BorderStyle.None;
            pictureBox16.BorderStyle = BorderStyle.None;
            pictureBox17.BorderStyle = BorderStyle.None;
            i = 1;
            label4.Visible = true;
        }

        private void pictureBox13_Click(object sender, EventArgs e)
        {
            pictureBox11.BorderStyle = BorderStyle.None;
            pictureBox12.BorderStyle = BorderStyle.None;
            pictureBox13.BorderStyle = BorderStyle.Fixed3D;
            pictureBox14.BorderStyle = BorderStyle.None;
            pictureBox15.BorderStyle = BorderStyle.None;
            pictureBox16.BorderStyle = BorderStyle.None;
            pictureBox17.BorderStyle = BorderStyle.None;
            i=1;
            label4.Visible = true;
        }

        private void pictureBox14_Click(object sender, EventArgs e)
        {
            pictureBox11.BorderStyle = BorderStyle.None;
            pictureBox12.BorderStyle = BorderStyle.None;
            pictureBox13.BorderStyle = BorderStyle.None;
            pictureBox14.BorderStyle = BorderStyle.Fixed3D;
            pictureBox15.BorderStyle = BorderStyle.None;
            pictureBox16.BorderStyle = BorderStyle.None;
            pictureBox17.BorderStyle = BorderStyle.None;
            i = 1;
            label4.Visible = true;
        }

        private void pictureBox15_Click(object sender, EventArgs e)
        {
            pictureBox11.BorderStyle = BorderStyle.None;
            pictureBox12.BorderStyle = BorderStyle.None;
            pictureBox13.BorderStyle = BorderStyle.None;
            pictureBox14.BorderStyle = BorderStyle.None;
            pictureBox15.BorderStyle = BorderStyle.Fixed3D;
            pictureBox16.BorderStyle = BorderStyle.None;
            pictureBox17.BorderStyle = BorderStyle.None;
            i = 1;
            label4.Visible = true;
        }

        private void pictureBox16_Click(object sender, EventArgs e)
        {
            pictureBox11.BorderStyle = BorderStyle.None;
            pictureBox12.BorderStyle = BorderStyle.None;
            pictureBox13.BorderStyle = BorderStyle.None;
            pictureBox14.BorderStyle = BorderStyle.None;
            pictureBox15.BorderStyle = BorderStyle.None;
            pictureBox16.BorderStyle = BorderStyle.Fixed3D;
            pictureBox17.BorderStyle = BorderStyle.None;
            i = 1;
            label4.Visible = true;
        }

        private void pictureBox17_Click(object sender, EventArgs e)
        {
            pictureBox11.BorderStyle = BorderStyle.None;
            pictureBox12.BorderStyle = BorderStyle.None;
            pictureBox13.BorderStyle = BorderStyle.None;
            pictureBox14.BorderStyle = BorderStyle.None;
            pictureBox15.BorderStyle = BorderStyle.None;
            pictureBox16.BorderStyle = BorderStyle.None;
            pictureBox17.BorderStyle = BorderStyle.Fixed3D;
            i = 1;
            label4.Visible = true;
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
